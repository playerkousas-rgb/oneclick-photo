/* 一鍵換角度 — content script
   由 popup 寫入 pendingPrompt,呢度負責:填入 Gemini 輸入框 (+ 自動送出) */
(function () {
  'use strict';

  function findBox() {
    const sels = [
      'rich-textarea div[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"]',
      'textarea'
    ];
    for (const s of sels) {
      const els = [...document.querySelectorAll(s)].filter(e => e.offsetParent !== null);
      if (els.length) return els[els.length - 1];
    }
    return null;
  }

  function insertText(box, text) {
    box.focus();
    if (box.tagName === 'TEXTAREA') {
      box.value = text;
      box.dispatchEvent(new Event('input', { bubbles: true }));
      return box.value === text;
    }
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(box);
      sel.removeAllRanges();
      sel.addRange(range);
      if (document.execCommand('insertText', false, text)) {
        if ((box.innerText || '').trim().length) return true;
      }
    } catch (e) {}
    try {
      box.innerHTML = '';
      const p = document.createElement('p');
      p.textContent = text;
      box.appendChild(p);
      box.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
      return (box.innerText || '').includes(text.slice(0, 10));
    } catch (e) { return false; }
  }

  function clickSend() {
    const cands = [
      'button[aria-label*="Send message"]',
      'button[aria-label*="傳送"]',
      'button[aria-label*="发送"]',
      'button.send-button',
      'button[aria-label*="Send"]'
    ];
    for (const s of cands) {
      const b = [...document.querySelectorAll(s)].filter(e => e.offsetParent !== null && !e.disabled);
      if (b.length) { b[b.length - 1].click(); return true; }
    }
    const box = findBox();
    if (box) {
      ['keydown', 'keypress', 'keyup'].forEach(t =>
        box.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })));
      return true;
    }
    return false;
  }

  function fillWithRetry(text, autoSubmit, attempt) {
    attempt = attempt || 0;
    const box = findBox();
    if (!box) {
      if (attempt < 24) return setTimeout(() => fillWithRetry(text, autoSubmit, attempt + 1), 400);
      showBar(text, '搵唔到 Gemini 輸入框。請按下面按鈕手動填入:');
      return;
    }
    const ok = insertText(box, text);
    if (!ok) {
      if (attempt < 8) return setTimeout(() => fillWithRetry(text, autoSubmit, attempt + 1), 500);
      showBar(text, '自動填入失敗(Google 改過介面?)。請按下面按鈕手動填入:');
      return;
    }
    chrome.storage.local.remove(['pendingPrompt', 'pendingSubmit', 'pendingToken']);
    showToast(autoSubmit ? '✅ 已填入並送出' : '✅ 已填入,撳 Send 就得');
    if (autoSubmit) setTimeout(clickSend, 200);
  }

  /* -------- 頁面提示 / 後備小工具 -------- */
  let toastEl;
  function showToast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:2147483647;' +
        'background:#161a24;color:#fff;border:1px solid #2d3546;padding:11px 16px;border-radius:99px;' +
        'font:600 13px/1.4 system-ui,-apple-system,"PingFang HK",sans-serif;box-shadow:0 8px 30px #0008;' +
        'transition:opacity .25s;opacity:0';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.style.opacity = '1';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => { toastEl.style.opacity = '0'; }, 2600);
  }

  let barEl;
  function showBar(text, msg) {
    if (!barEl) {
      barEl = document.createElement('div');
      barEl.style.cssText = 'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:2147483647;' +
        'background:#101a2e;color:#dce9ff;border:1px solid #2c4a7c;padding:12px 14px;border-radius:14px;' +
        'font:500 13px/1.5 system-ui,-apple-system,"PingFang HK",sans-serif;max-width:min(92vw,520px);' +
        'box-shadow:0 10px 40px #000a;display:flex;gap:10px;align-items:center;flex-wrap:wrap';
      document.body.appendChild(barEl);
    }
    barEl.innerHTML = '';
    const s = document.createElement('span');
    s.textContent = msg;
    const b = document.createElement('button');
    b.textContent = '填入指令';
    b.style.cssText = 'background:#4f8cff;color:#fff;border:0;padding:7px 12px;border-radius:9px;font-weight:700;cursor:pointer';
    b.onclick = () => {
      const box = findBox();
      if (box && insertText(box, text)) { showToast('✅ 已填入,撳 Send 就得'); barEl.remove(); barEl = null; }
      else showToast('⚠️ 都係填唔到,可以喺頁面手動貼上');
    };
    const x = document.createElement('button');
    x.textContent = '✕';
    x.style.cssText = 'background:transparent;color:#8ea6cf;border:0;font-size:14px;cursor:pointer';
    x.onclick = () => { barEl.remove(); barEl = null; };
    barEl.append(s, b, x);
  }

  /* -------- 讀取待處理指令 -------- */
  let lastToken = '';
  function check() {
    chrome.storage.local.get(['pendingPrompt', 'pendingSubmit', 'pendingToken'], d => {
      const p = d && d.pendingPrompt;
      const tok = String(d && d.pendingToken || '');
      if (!p || tok === lastToken) return;
      lastToken = tok || p;   // 冇 token 嘅舊版資料都處理到
      fillWithRetry(p, !!d.pendingSubmit);
    });
  }
  check();
  /* 同一個效果撳第二次都要再觸發:每次都帶新 token,所以監聽 token 而唔係 prompt 內容 */
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && (ch.pendingToken || ch.pendingPrompt)) check();
  });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
})();
