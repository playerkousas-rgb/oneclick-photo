/* 一鍵換角度 — popup:揀效果 → 寫入 storage → 開/切去 Gemini 分頁 */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let curCat = window.CATS[0][0];
let query = '';
let autoSubmit = true;

function loadPref(){
  chrome.storage.local.get(['autoSubmit'], d => {
    autoSubmit = d && d.autoSubmit === false ? false : true;
    $('#auto').classList.toggle('on', autoSubmit);
    $('#autoState').textContent = autoSubmit ? '開(自動送出)' : '關(只填入)';
  });
}
$('#auto').onclick = () => {
  autoSubmit = !autoSubmit;
  chrome.storage.local.set({ autoSubmit });
  $('#auto').classList.toggle('on', autoSubmit);
  $('#autoState').textContent = autoSubmit ? '開(自動送出)' : '關(只填入)';
};

function renderTabs(){
  $('#tabs').innerHTML = window.CATS.map(([id, label]) =>
    `<button class="tab ${id===curCat?'active':''}" data-cat="${id}">${label}</button>`).join('');
  $$('#tabs .tab').forEach(b => b.onclick = () => { curCat = b.dataset.cat; renderTabs(); renderGrid(); });
}
function renderGrid(){
  const q = query.trim().toLowerCase();
  const list = q ? window.PRESETS.filter(p => (p.zh+p.slug+p.tip+p.prompt).toLowerCase().includes(q))
                 : window.PRESETS.filter(p => p.cat === curCat);
  $('#grid').innerHTML = list.map(p => `
    <button class="card" data-slug="${p.slug}" title="${p.tip}">
      <img src="${window.THUMBS[p.slug]||''}" alt="">
      <span class="nm">${p.zh}</span>
    </button>`).join('');
  $$('#grid .card').forEach(c => c.onclick = () => send(window.PRESETS.find(p => p.slug === c.dataset.slug)));
}

function send(p){
  if(!p) return;
  const token = Date.now() + '-' + Math.random().toString(36).slice(2);
    chrome.storage.local.set({ pendingPrompt: p.prompt, pendingSubmit: autoSubmit, pendingToken: token }, () => {
    chrome.tabs.query({ url: 'https://gemini.google.com/*' }, tabs => {
      if (tabs && tabs.length) {
        const t = tabs[0];
        chrome.tabs.update(t.id, { active: true }, () => chrome.windows.update(t.windowId, { focused: true }));
      } else {
        chrome.tabs.create({ url: 'https://gemini.google.com/app' });
      }
      $('#status').textContent = p.zh + ' → 已送去 Gemini 👍';
      $('#status').className = 'status ok';
    });
  });
}

$('#search').oninput = e => { query = e.target.value; renderGrid(); };
$('#openGem').onclick = () => chrome.tabs.create({ url: 'https://gemini.google.com/app' });
$('#openUpload').onclick = () => {
  $('#guide').textContent = '① 喺 Gemini 撳 ➕ 上載你嘅相 → ② 返嚟呢度揀效果 → ③ 佢自動幫你打入去並送出';
  $('#guide').style.display = 'block';
};

loadPref(); renderTabs(); renderGrid();
